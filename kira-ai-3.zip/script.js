const togetherKey = "tgp_v1_-z_z4kiRlypHdSa5W66HgZRiy9YKz5fTk1LTsxzR5BE";
const geminiKey = "AIzaSyCMUiEcoVa9pa9e0mvPvWa5KVLBW9awecg";

const chatBox = document.getElementById("chat-box");
const userInput = document.getElementById("user-input");

function addMessage(sender, text) {
  const message = document.createElement("div");
  message.innerHTML = `<strong>${sender}:</strong> ${text}`;
  chatBox.appendChild(message);
  chatBox.appendChild(document.createElement("br"));
  chatBox.scrollTop = chatBox.scrollHeight;
}

async function sendMessage() {
  const input = userInput.value.trim();
  if (!input) return;
  addMessage("You", input);
  userInput.value = "";

  let answer = await getEasterEgg(input);
  if (!answer) {
    answer = await getWiki(input);
    if (!answer) answer = await queryTogether(input);
    if (!answer) answer = await getDuckDuckGo(input);
    if (!answer) answer = await getGoogleSummary(input);
    if (!answer) answer = await queryGemini(input);
  }

  addMessage("Kira", answer || "❌ Sorry, I couldn't find an answer.");
}

async function getEasterEgg(input) {
  const q = input.toLowerCase();
  if (q.includes("tester")) return "👾 First tester of Kira AI is Hirokjyoti Handique.";
  if (q.includes("who created kira")) return "👨‍💻 Kira AI was created by Kapil Kaustav Das.";
  return null;
}

async function getWiki(input) {
  try {
    const res = await fetch("https://en.wikipedia.org/api/rest_v1/page/summary/" + encodeURIComponent(input));
    const data = await res.json();
    return data.extract || null;
  } catch {
    return null;
  }
}

async function getDuckDuckGo(input) {
  try {
    const url = "https://api.duckduckgo.com/?q=" + encodeURIComponent(input) + "&format=json&no_redirect=1";
    const res = await fetch(url);
    const data = await res.json();
    return data.AbstractText || null;
  } catch {
    return null;
  }
}

async function getGoogleSummary(input) {
  try {
    const url = "https://ddg-api.herokuapp.com/search?q=" + encodeURIComponent(input);
    const res = await fetch(url);
    const data = await res.json();
    return data?.Answer || null;
  } catch {
    return null;
  }
}

async function queryTogether(input) {
  try {
    const response = await fetch("https://api.together.xyz/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": "Bearer " + togetherKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "deepseek-chat",
        messages: [{ role: "user", content: input }]
      })
    });
    const data = await response.json();
    return data.choices?.[0]?.message?.content || null;
  } catch {
    return null;
  }
}

async function queryGemini(input) {
  try {
    const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" + geminiKey, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        contents: [{ parts: [{ text: input }] }]
      })
    });
    const data = await response.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text || null;
  } catch {
    return null;
  }
}