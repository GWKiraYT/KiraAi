const siteUrl = "https://gwkirayt.github.io/KiraAi/";
const siteName = "Kira AI";
const openRouterKey = "sk-***blackened***"; // Your API key here (blackened)
const chatBox = document.getElementById("chat-box");
const userInput = document.getElementById("user-input");

function addMessage(sender, text) {
  const message = document.createElement("div");
  message.className = "message";
  const speakBtn = `<button class='read-btn' onclick='speakText(${JSON.stringify(text)})'>🔊</button>`;
  message.innerHTML = `<strong>${sender}:</strong> ${text} ${speakBtn}`;
  chatBox.appendChild(message);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function speakText(text) {
  const msg = new SpeechSynthesisUtterance(text);
  window.speechSynthesis.speak(msg);
}

async function sendMessage() {
  const input = userInput.value.trim();
  if (!input) return;
  addMessage("You", input);
  userInput.value = "";

  try {
    let response = await fetch("https://en.wikipedia.org/api/rest_v1/page/summary/" + encodeURIComponent(input));
    let data = await response.json();
    let answer = data.extract;

    if (!answer || input.length <= 4) {
      const searchURL = "https://api.duckduckgo.com/?q=" + encodeURIComponent(input) + "&format=json&no_redirect=1";
      const ddgRes = await fetch(searchURL);
      const ddgData = await ddgRes.json();
      answer = ddgData.AbstractText || ddgData.Heading;
    }

    if (!answer && input.toLowerCase().includes("weather")) {
      const weatherRes = await fetch("https://wttr.in/" + encodeURIComponent(input.replace("weather", "").trim()) + "?format=3");
      answer = await weatherRes.text();
    }

    if (!answer) {
      const routerRes = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": "Bearer " + openRouterKey,
          "HTTP-Referer": siteUrl,
          "X-Title": siteName,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "openai/gpt-4o",
          messages: [{ role: "user", content: input }]
        })
      });
      const routerData = await routerRes.json();
      answer = routerData.choices?.[0]?.message?.content || "Sorry, I couldn't find an answer.";
    }

    addMessage("Kira", answer);
  } catch (err) {
    addMessage("Kira", "Error fetching answer.");
  }
}